/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-43e44e5a'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "c72a0bdbd7f01409e7d949fa1eda46fa"
  }, {
    "url": "pwa-512x512.png",
    "revision": "2a0eaa6265edb638316f5a210e318b5e"
  }, {
    "url": "pwa-192x192.png",
    "revision": "455b4146886c3fa5f206ffd5d775e6db"
  }, {
    "url": "index.html",
    "revision": "361392ec99a5f197870a105150d4bde0"
  }, {
    "url": "favicon.png",
    "revision": "8dfd35d3c0b8e69aade9ffdc03e2b4f8"
  }, {
    "url": "favicon.ico",
    "revision": "99ce6ff4dab9c4eadab9807a0e5208b6"
  }, {
    "url": "favicon-g-emblem.png",
    "revision": "395a2b250fa99a61c09ae70d5b1b04c8"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "804694943652b579e0efe3bb887ff238"
  }, {
    "url": "assets/workbox-window.prod.es5-Bd17z0YL.js",
    "revision": null
  }, {
    "url": "assets/index-QWqXRcH6.js",
    "revision": null
  }, {
    "url": "assets/index-DgFnRnzt.css",
    "revision": null
  }, {
    "url": "assets/aistudio/gulfaro_logo_ff1eae03.png",
    "revision": null
  }, {
    "url": "assets/aistudio/Gulfaro_logo_white_transparent.png",
    "revision": null
  }, {
    "url": "assets/aistudio/Gulfaro_logo_white_clean.png",
    "revision": null
  }, {
    "url": "assets/aistudio/Gulfaro_logo_96e9f0a2.png",
    "revision": null
  }, {
    "url": "assets/aistudio/767676_2b0c4b1e.png",
    "revision": null
  }, {
    "url": "assets/aistudio/1313_1c3f88f4.png",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "804694943652b579e0efe3bb887ff238"
  }, {
    "url": "favicon-g-emblem.png",
    "revision": "395a2b250fa99a61c09ae70d5b1b04c8"
  }, {
    "url": "favicon.ico",
    "revision": "99ce6ff4dab9c4eadab9807a0e5208b6"
  }, {
    "url": "manifest.json",
    "revision": "70d30918c977266d97f04086696d7332"
  }, {
    "url": "pwa-192x192.png",
    "revision": "455b4146886c3fa5f206ffd5d775e6db"
  }, {
    "url": "pwa-512x512.png",
    "revision": "2a0eaa6265edb638316f5a210e318b5e"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "c72a0bdbd7f01409e7d949fa1eda46fa"
  }, {
    "url": "manifest.webmanifest",
    "revision": "8403fc972af2ac492d5bcaa81fe179c7"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html"), {
    denylist: [/^\/api\/.*/, /^\/sitemap\.xml$/, /^\/robots\.txt$/]
  }));
  workbox.registerRoute(/\/gulfaro-config\.js$/i, new workbox.NetworkOnly(), 'GET');
  workbox.registerRoute(/^\/api\/.*/i, new workbox.NetworkOnly(), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
